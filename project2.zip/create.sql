USE CS144;
CREATE TABLE User( UserID varchar(80) PRIMARY KEY, Bid_Rating varchar(80), Sell_Rating varchar(80), Location varchar(80), Country varchar(80) );
CREATE TABLE ItemCat( ItemID varchar(80), Category varchar(80), PRIMARY KEY(ItemID, Category));
CREATE TABLE Bid( ItemID varchar(80), UserID varchar(80), Time TIMESTAMP, Amount Decimal(8,2), PRIMARY KEY(ItemID, UserID, Time)  );
CREATE TABLE Item( ItemID varchar(80) PRIMARY KEY, Name varchar(80), Buy_Price Decimal(8,2), Currently Decimal(8,2), Number_of_Bids varchar(80), First_Bid Decimal(8,2), Location varchar(80), Latitude varchar(80), Longitude varchar(80), Country varchar(80), Started TIMESTAMP, Ends TIMESTAMP, Description varchar(4000), UserID varchar(80) );
