package edu.ucla.cs.cs144;

public class User {
	public String user_id;
	public String bid_rating;
	public String sell_rating;
	public String location;
	public String country;
	public User(){
		user_id = "";
		bid_rating = "";
		sell_rating = "";
		location = "";
		country = "";
	}
}
