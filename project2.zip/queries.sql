SELECT Count(UserID) FROM User;
SELECT Count(Location) FROM Item WHERE BINARY Location = 'New York';
SELECT Count(*) FROM (SELECT COUNT(*) as x FROM ItemCat GROUP BY ItemID HAVING x = 4) as y;
SELECT Bid.ItemID FROM Bid INNER JOIN Item ON Bid.ItemID = Item.ItemID WHERE Ends > '2001-12-20 00:00:01' AND Amount = (SELECT MAX(Amount) FROM Bid INNER JOIN Item ON Bid.ItemID = Item.ItemID WHERE Ends > '2001-12-20 00:00:01');    
SELECT Count(UserID) FROM User WHERE Sell_Rating > 1000;
SELECT Count(UserID) FROM User WHERE Sell_Rating > 0 AND Bid_Rating > 0;
SELECT COUNT(DISTINCT Category) FROM ItemCat INNER JOIN Bid ON Bid.ItemID=ItemCat.ItemID WHERE Amount > 100;
