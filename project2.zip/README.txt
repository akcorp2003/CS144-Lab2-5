1. Schema
User(UserID(Primary Key), Location, Country, Bid_Rating, Sell_Rating);
ItemCat(ItemID, Category);
Bid(ItemID, UserID, Time, Amount);
Item( ItemID PRIMARY KEY, Name, Buy_Price , Currently , Number_of_Bids, First_Bid , Location, Latitude , Longitude , Country, Started, Ends, Description, UserID )

2. Our schema is in BCNF form as well as 4NF form and does not have any nontrivial functional dependencies.

Late Submission Note: We are using 1 of our 4 grace days. We still have 3 grace days left.
