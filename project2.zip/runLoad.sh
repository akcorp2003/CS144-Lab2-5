#!/bin/bash

chmod a+x runLoad.sh

mysql CS144 < drop.sql

mysql CS144 < create.sql

ant run-all

mysql CS144 < load.sql

rm output.csv


